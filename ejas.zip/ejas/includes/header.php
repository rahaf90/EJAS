
   

  
      
    
      
      
      <header class="site-navbar py-1" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
              <!--THE LOGO IN THE NAVIGATION BAR-->
            <h1 class="mb-0"><a href="index.php" class="text-black h2 mb-0"><strong>EJAS</strong></a></h1>
          </div>
            
            
           <!-- A SEARCH FOR CATEGORIES-->
          <div class="col-10 col-xl-10 d-none d-xl-block">
            <nav class="site-navigation text-right" role="navigation">

              <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
               <li> <div class="col-md-6 col-lg-12 mb-3 mb-lg-0">
                       
                        <input type="text" class="form-control " placeholder="eg. Web Developer">
                       
                        
                      
                      </div>
                       
                      </li>
                      
                      
                      
                <li class="active"><a href="index.php">Home</a></li>
                <li class="has-children">
                  <a href="category.php">Category</a>
                  <ul class="dropdown">
                    <li><a href="#">Full Time</a></li>
                    <li><a href="#">Part Time</a></li>
                    <li><a href="#">Freelance</a></li>
                    <li><a href="#">Internship</a></li>
                    <li><a href="#">Termporary</a></li>
                  </ul>
                </li>
                <li><a href="about.php">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                 
                  <li class="has-children">
                  
                  <button style="border:none;cursor:pointer;" on class="rounded bg-primary py-2 px-2 text-white">Sign up / Log in</button>
               <ul class="dropdown">
                    <li><a href="organization_signup_page.php">As an organization</a></li>
                    <li><a href="signup_page.php">As an applicant </a></li>
                    
                  </ul>
                  </li>
                  
                 
              </ul>
            </nav>
          </div>

          <div class="col-6 col-xl-2 text-right d-block">
            
            <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>
    
   