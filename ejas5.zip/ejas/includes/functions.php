
<?php

/***** helper functions *************/

//clean anything wrong with input like #$@$%
function clean($string){
    
    return htmlentities($string);
}

function redirect($location){


return header("Location: {$location}");

}

// to not lose the value when going to another page or redirecting like "password updated", instead of echoing, and to see it anywhere in the site

function set_message($message){
    
    
    if(!empty($message)){
        
        //save it in session
        $_SESSION['message']=$message;
        
        
    }else{
        
        
        $message="";
    }
        
    
}


function display_message(){
    
    if(isset($_SESSION['message'])){
        
        
        
        echo $_SESSION['message'];
        
        // so it doesnt stay there all the time.
        unset($_SESSION['message']);
    }
    
    
    
}

//to make forms secure,encrypted string

function token_generator(){
    
    //it will produce unique id,and mt_rand()will provide random values,and md5 will encrypt all this and "true" make it longer and more secure with a prefix
  $token =$_SESSION['token']= md5(uniqid(mt_rand(), true));  
    
    return $token ;
    
    
}

function validation_errors($error_message){
    // we use delimeter so that double or single '' "" wont matter
  $error_message= <<<DELIMITER
         
  <div class="alert alert-danger alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Warning!</strong> $error_message </div>
               
DELIMITER;
               
    return $error_message;        
}


function email_exists($email){
    
    $sql = "SELECT org_id FROM organization-register WHERE org_emai = '$email'";
    // calling function query from db.php
    $result = query($sql);
    // row_count() we created in db.php to count how many rows are coming back
    if(row_count($result) == 1){
        
     return true;   
        
        
    }else{
        
      return false;  
        
    }
    
    
    
}

function name_exists($name){
    
    $sql = "SELECT org_id FROM organization-register WHERE org_name = '$name'";
    // calling function query from db.php
    $result = query($sql);
    // row_count() we created in db.php to count how many rows are coming back
    if(row_count($result) == 1){
        
     return true;   
          
    }else{
        
      return false;  
        
    }
    
    
    
}




/***** validation functions *************/

function validate_user_registration(){
    $errors=[];
    $min=3;
    $max=50;
    $post_max=12;
    $post_min=5;
    
   if($_SERVER['REQUEST_METHOD'] == "POST") {
       
      $name        = clean($_POST['name']);
      $email       = clean($_POST['email']);
      $address     = clean($_POST['address']);
      $postcode    = clean($_POST['postcode']);
      $password    = clean($_POST['pass']);
      $confirmpass = clean($_POST['confirmpass']);
      //strlen to check how many characters
       if(strlen($name) < $min){
            
           $errors[] = "Your name cannot be less then {$min} characters";  
       }
       
        
       if(strlen($address) < $min){
            
           $errors[] = "Your address cannot be less then {$min} characters";  
       }
       
       
       if(strlen($postcode) < $post_min){
            
           $errors[] = "Your postcode cannot be less then {$post_min} characters or numbers";  
       }
       
       
       if(strlen($postcode) > $post_max){
            
           $errors[] = "Your postcode cannot be more then {$post_max} characters or numbers";  
       }
       
       
       if(strlen($name) > $max){
            
           $errors[] = "Your name cannot be more then {$max} characters";  
       }
       
       if(strlen($address) > $max){
            
           $errors[] = "Your address cannot be more then {$max} characters";  
       }
       
       if($password !== $confirmpass){
           
            $errors[] = "Your password fields do not match";
           
       }
       
       
       if(email_exists($email)){
           
           
            $errors[] = "Sorry that email already registered";
  
           
           
       }
       
       if(name_exists($name)){
           
           
            $errors[] = "Sorry that name already taken";
     
           
       }
       
       if(!empty($errors)){
           
           foreach($errors as $error){
                       
           //error display
               
               echo validation_errors($error); 
           }     
       }
       
    //pull out values
       
   // another one to use
       //if(isset($_POST['register-submit'])){
        
       //echo "it works" ;
        
   
    }
   }
    
    
    








?>